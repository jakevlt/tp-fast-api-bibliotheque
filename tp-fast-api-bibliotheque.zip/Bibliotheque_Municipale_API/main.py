books = [
{
"id": 1,
"titre": "Le Petit Prince", "auteur": "Saint-Exupéry",
"annee": 1943,
"categorie": "conte"
}
]

users = []

from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def accueil():
    return {"message": "Bienvenue"}

@app.get("/books")
def get_books():
    return books

@app.get("/books/{id}")
def get_book(id: int):
    for book in books:
        if book["id"] == id:
            return book
    return {"error": "Livre non trouvé"}

@app.get("/books/search/{titre}")
def get_book_title(titre: str):
    for book in books:
        if book["titre"] == titre:
            return book
    return {"error": "Livre rechercher non trouvé"}

@app.get("/books/category/{categorie}")
def get_book_category(categorie: str):
    for book in books:
        if book["categorie"] == categorie:
            return book
    return {"error": "Catégorie rechercher non trouvé"}

@app.get("/stats")
def get_stats():
    return {
        "nbLivres": len(books),
        "nbUtilisateurs": len(users)
    }

@app.post("/books")
def add_book(book: dict):
    books.append(book)
    return {"message": "Livre ajouté", "book": book}

@app.put("/books/{id}")
def update_book(id: int, updated_book: dict):
    for i, book in enumerate(books):
        if book["id"] == id:
            books[i] = updated_book
            return {"message": "Livre modifié", "book": updated_book}
    return {"error": "Livre non trouvé"}

@app.delete("/books/{id}")
def delete_book(id: int):
    global books
    books = [b for b in books if b["id"] != id]
    return {"message": "Livre supprimé"}

@app.post("/users")
def add_user(user: dict):
    users.append(user)
    return {"message": "Utilisateur créé", "user": user}

@app.post("/login")
def login(credentials: dict):
    login = credentials.get("login")
    password = credentials.get("password")

    if login == "admin" and password == "admin":
        return {"token": "123456", "message": "Connexion réussie"}
    return {"error": "Identifiants invalides"}
