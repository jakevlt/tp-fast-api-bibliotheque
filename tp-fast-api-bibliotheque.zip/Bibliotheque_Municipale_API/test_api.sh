#!/bin/bash
# Script de test de l'API Bibliothèque Municipale (FastAPI)
# Teste toutes les routes CRUD + les fonctionnalités de la mission finale
# Usage : bash test_api.sh   (le serveur doit déjà tourner : uvicorn main:app --reload)

BASE_URL="http://127.0.0.1:8000"

# Détecte la commande Python disponible (python ou python3) pour formater le JSON
if command -v python3 &> /dev/null; then
    PYTHON=python3
elif command -v python &> /dev/null; then
    PYTHON=python
else
    PYTHON=""
fi

format_json() {
    if [ -n "$PYTHON" ]; then
        $PYTHON -m json.tool
    else
        cat
    fi
}

echo "=== Test API Bibliothèque ==="

echo -e "\n1. Route racine"
curl -s "$BASE_URL/" | format_json

echo -e "\n2. Récupérer tous les livres"
curl -s "$BASE_URL/books" | format_json

echo -e "\n3. Récupérer le livre 1 (recherche par ID - Mission finale)"
curl -s "$BASE_URL/books/1" | format_json

echo -e "\n4. Rechercher un livre par titre"
curl -s "$BASE_URL/books/search/Le%20Petit%20Prince" | format_json

echo -e "\n5. Rechercher un livre par catégorie"
curl -s "$BASE_URL/books/category/conte" | format_json

echo -e "\n6. Statistiques"
curl -s "$BASE_URL/stats" | format_json

echo -e "\n7. Ajouter un livre"
curl -s -X POST "$BASE_URL/books" \
  -H "Content-Type: application/json" \
  -d '{"id": 3, "titre": "Dune", "auteur": "Frank Herbert", "annee": 1965, "categorie": "science-fiction"}' \
  | format_json

echo -e "\n8. Modifier le livre 1"
curl -s -X PUT "$BASE_URL/books/1" \
  -H "Content-Type: application/json" \
  -d '{"id": 1, "titre": "Le Petit Prince (édition spéciale)", "auteur": "Saint-Exupéry", "annee": 1943, "categorie": "conte"}' \
  | format_json

echo -e "\n9. Supprimer le livre 3"
curl -s -X DELETE "$BASE_URL/books/3" | format_json

echo -e "\n10. Ajouter un nouvel utilisateur (Mission finale)"
curl -s -X POST "$BASE_URL/users" \
  -H "Content-Type: application/json" \
  -d '{"id": 1, "nom": "Alice", "email": "alice@test.fr"}' \
  | format_json

echo -e "\n11. Se connecter avec login/password (Mission finale)"
curl -s -X POST "$BASE_URL/login" \
  -H "Content-Type: application/json" \
  -d '{"login": "admin", "password": "admin"}' \
  | format_json

echo -e "\n=== Tests terminés ==="
