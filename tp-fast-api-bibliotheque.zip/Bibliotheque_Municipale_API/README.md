# TP FastAPI — API REST Bibliothèque Municipale

API REST développée avec FastAPI dans le cadre du TP "Création d'une API REST avec FastAPI" (BTS SIO 2e année).

## Contenu du dossier

| Fichier | Rôle |
|---|---|
| `main.py` | Code source de l'API |
| `test_api.sh` | Script de test de toutes les routes avec cURL |
| `test_api_advanced.ps1` | Script de test avancé (Exercice 5) avec sauvegarde dans un fichier de log horodaté |
| `tp_API_collection.postman_collection.json` | Collection Postman exportée (toutes les routes, avec bodies) |
| `swagger_captures.pdf` | Captures d'écran Swagger de chaque route |

## Installation

```bash
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # Linux/Mac
pip install fastapi uvicorn
```

## Lancer le serveur

```bash
python -m uvicorn main:app --reload
```

L'API est alors accessible sur `http://127.0.0.1:8000`, et la documentation interactive Swagger sur `http://127.0.0.1:8000/docs`.

## Routes disponibles

| Méthode | Route | Description |
|---|---|---|
| GET | `/` | Message de bienvenue |
| GET | `/books` | Liste tous les livres |
| GET | `/books/{id}` | Récupère un livre par son ID |
| GET | `/books/search/{titre}` | Recherche un livre par titre |
| GET | `/books/category/{categorie}` | Recherche un livre par catégorie |
| GET | `/stats` | Statistiques (nombre de livres, d'utilisateurs) |
| POST | `/books` | Ajoute un livre |
| PUT | `/books/{id}` | Modifie un livre |
| DELETE | `/books/{id}` | Supprime un livre |
| POST | `/users` | Ajoute un utilisateur |
| POST | `/login` | Connexion (login/password) |

## Tester avec cURL

Le script `test_api.sh` teste automatiquement toutes les routes ci-dessus, dans l'ordre, et affiche chaque réponse JSON formatée.

**Prérequis** : le serveur doit être démarré (`python -m uvicorn main:app --reload`) avant de lancer le script.

**Sous Windows**, deux options pour exécuter un script `.sh` :
- **Via WSL** (si installé) : ouvrez un terminal Ubuntu, placez-vous dans le dossier du projet (`cd /mnt/c/projets/tp_API`), puis lancez `bash test_api.sh`.
- **Via Git Bash** (fourni avec Git pour Windows) : clic droit dans le dossier → « Git Bash Here », puis `bash test_api.sh`.

**Sous Linux/Mac**, directement :
```bash
bash test_api.sh
```

### Exemple de requête cURL individuelle

Récupérer tous les livres :
```bash
curl http://127.0.0.1:8000/books
```

Ajouter un livre :
```bash
curl -X POST http://127.0.0.1:8000/books \
  -H "Content-Type: application/json" \
  -d '{"id": 3, "titre": "Dune", "auteur": "Frank Herbert", "annee": 1965, "categorie": "science-fiction"}'
```

Se connecter :
```bash
curl -X POST http://127.0.0.1:8000/login \
  -H "Content-Type: application/json" \
  -d '{"login": "admin", "password": "admin"}'
```

## Tester avec Postman

1. Ouvrir Postman.
2. Importer `tp_API_collection.postman_collection.json` (bouton **Import**).
3. S'assurer que le serveur FastAPI tourne.
4. Exécuter chaque requête de la collection avec **Send**.

## Tester avec Swagger

1. Ouvrir `http://127.0.0.1:8000/docs` dans un navigateur.
2. Cliquer sur une route pour la déplier.
3. Cliquer sur **Try it out**, remplir les paramètres si besoin, puis **Execute**.
4. Le résultat (code HTTP + réponse JSON) s'affiche sous la requête.

Voir `swagger_captures.pdf` pour la preuve de ces tests sur toutes les routes.

## Mission finale — fonctionnalités validées

- ✅ Obtenir la liste complète des livres (`GET /books`)
- ✅ Rechercher un livre par ID (`GET /books/{id}`)
- ✅ Ajouter un nouvel utilisateur (`POST /users`)
- ✅ Se connecter avec login/password (`POST /login`)
- ✅ Tous les tests exécutables depuis cURL (`test_api.sh`)

## Exercices complétés

- **Exercice 1** : ajout du champ `annee` aux livres
- **Exercice 2** : recherche par titre (`GET /books/search/{titre}`)
- **Exercice 3** : ajout du champ `categorie` + recherche par catégorie (`GET /books/category/{categorie}`)
- **Exercice 4** : statistiques (`GET /stats`)
- **Exercice 5** : script cURL avancé avec sauvegarde des résultats dans un fichier de log horodaté (`test_api_advanced.ps1`)
